#ifndef DEBUG_HPP
#define DEBUG_HPP

#ifdef DEBUG
#define debug(x) (x)
#else
#define debug(x)
#endif

#endif // DEBUG_HPP
