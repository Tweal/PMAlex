// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "unittest_alex.h"
#include "unittest_alex_map.h"
#include "unittest_alex_multimap.h"
#include "unittest_nodes.h"
