Packed-Memory Array
==

Packed-Memory Array as described in [1, 2, 3, 4].

[1] Michael A. Bender, Erik D. Demaine, and Martin Farach-Colton.
    Cache-oblivious B-trees. In Proceedings of the 41st Annual Symposium on
    Foundations of Computer Science (FOCS '00), pages 399--409, Redondo Beach,
    California, USA, November 2000. IEEE Computer Society.

[2] Michael A. Bender, Erik D. Demaine, and Martin Farach-Colton.
    Cache-oblivious B-trees. SIAM Journal on Computing, 35(2):341--358, 2005.

[3] Michael A. Bender and Haodong Hu. An adaptive packed-memory array. In
    Proceedings of the 25th ACM SIGACT-SIGMOD-SIGART Symposium on Principles of
    Database Systems (PODS '06), pages 20--29, Chicago, Illinois, USA, June
    2006. ACM.

[4] Michael A. Bender and Haodong Hu. An adaptive packed-memory array. ACM
    Trans. Database Syst., 32(4), November 2007.
