/*
 * Copyright (c) 2014 Pablo Montes <pabmont@gmail.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef __PMA_H_
#define __PMA_H_

#include <stdio.h>

#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

#include "keyval.h"
#include "util.h"

/* Reserve 8 bits to allow for fixed point arithmetic. */
#define MAX_SIZE ((1ULL << 56) - 1ULL)

/* Height-based (as opposed to depth-based) thresholds. */
/* Upper density thresholds. */
static const double t_h = 0.75;  /* root. */
static const double t_0 = 1.00;  /* leaves. */
/* Lower density thresholds. */
static const double p_h = 0.50;  /* root. */
static const double p_0 = 0.25;  /* leaves. */

static const uint8_t max_sparseness = 1 / p_0;
static const uint8_t largest_empty_segment = 1 * max_sparseness;

struct _pma;
typedef struct _pma pma_t, *PMA;

PMA pma_create (void);
PMA pma_from_array (keyval_t *array, uint64_t n);
void pma_destroy (PMA *pma);
bool pma_find (PMA pma, key_tt key, int64_t *index);
bool pma_insert (PMA pma, key_tt key, val_tt val);
void pma_insert_after (PMA pma, int64_t i, key_tt key, val_tt val);
bool pma_delete (PMA pma, key_tt key);
void pma_delete_at (PMA pma, int64_t i);
void pma_get (PMA pma, int64_t i, keyval_t *keyval);
uint64_t pma_capacity (PMA p);
uint64_t pma_count (PMA p);

/* TODO: For testing purposes only. */
uint8_t pma_segment_size (PMA pma);

#endif  /* __PMA_H_ */
